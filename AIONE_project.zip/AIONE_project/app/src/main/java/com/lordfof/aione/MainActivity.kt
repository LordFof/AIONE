package com.lordfof.aione

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private enum class Module(val title: String, val imageRes: Int) {
    HOME("Domů", R.drawable.ic_aione),
    YOUTUBE("YouTube", R.drawable.ic_youtube),
    TIKTOK("TikTok", R.drawable.ic_tiktok),
    INSTAGRAM("Instagram", R.drawable.ic_instagram),
    FACEBOOK("Facebook", R.drawable.ic_facebook),
    SETTINGS("Nastavení", R.drawable.ic_settings)
}

private val neonBlue = Color(0xFF19CFFF)
private val neonPurple = Color(0xFF8D35FF)
private val neonPink = Color(0xFFFF20B8)
private val pageBackground = Color(0xFF03040A)
private val panelBackground = Color(0xE80A0D18)
private val textPrimary = Color(0xFFF8F8FF)
private val textSecondary = Color(0xFFD8DBEA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AioneApp() }
    }
}

@Composable
private fun AioneApp() {
    var selected by remember { mutableStateOf(Module.HOME) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(pageBackground)) {
            Image(
                painter = painterResource(R.drawable.aione_neon_frame),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.72f
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.32f)))

            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = { AioneBottomBar(selected = selected, onSelect = { selected = it }) }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when (selected) {
                        Module.HOME -> HomeScreen(onOpenYouTube = { selected = Module.YOUTUBE })
                        Module.YOUTUBE -> YouTubeScreen()
                        Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK -> ComingSoonScreen(selected.title)
                        Module.SETTINGS -> SettingsScreen()
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(showSearch: Boolean = false, searchText: String = "", onSearchChange: (String) -> Unit = {}) {
    Row(
        modifier = Modifier.fillMaxWidth().height(76.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.aione_wordmark),
            contentDescription = "AIONE",
            modifier = Modifier.width(155.dp).height(58.dp),
            contentScale = ContentScale.Fit
        )
        if (showSearch) {
            NeonSearchField(searchText, onSearchChange, Modifier.weight(1f).height(58.dp))
        }
    }
}

@Composable
private fun HomeScreen(onOpenYouTube: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            NeonPanel {
                Text("Pro tebe", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Zatím žádné návrhy. AIONE nejdřív připojí skutečný YouTube obsah. Návrhy se objeví až po dokončení přehrávání a načítání YouTube.",
                    color = textSecondary, fontSize = 15.sp
                )
                Spacer(Modifier.height(14.dp))
                NeonButton("OTEVŘÍT YOUTUBE", onClick = onOpenYouTube)
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YouTubeScreen() {
    var url by remember { mutableStateOf("") }
    var videoId by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            NeonPanel {
                Text("YouTube", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Text("První skutečná část AIONE – přehrání skutečného YouTube videa.", color = textSecondary, modifier = Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; error = "" },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Vlož YouTube odkaz…") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = neonBlue,
                        unfocusedBorderColor = Color(0xFF33456E),
                        focusedTextColor = textPrimary,
                        unfocusedTextColor = textPrimary,
                        focusedContainerColor = Color(0xE8091020),
                        unfocusedContainerColor = Color(0xE8091020),
                        cursorColor = neonBlue
                    )
                )
                Spacer(Modifier.height(10.dp))
                NeonButton("PŘEHRÁT", onClick = {
                    val id = extractYouTubeId(url)
                    if (id == null) error = "Neplatný YouTube odkaz."
                    else videoId = id
                })
                if (error.isNotBlank()) {
                    Text(error, color = Color(0xFFFF6B8A), modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        if (videoId != null) {
            item {
                YouTubePlayer(videoId!!)
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YouTubePlayer(videoId: String) {
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(230.dp).clipNeon(),
        factory = { context ->
            WebView(context).apply {
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = true
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                setBackgroundColor(android.graphics.Color.BLACK)
                loadUrl("https://www.youtube.com/embed/$videoId?playsinline=1&rel=0")
            }
        },
        update = { webView ->
            val current = webView.url.orEmpty()
            if (!current.contains(videoId)) {
                webView.loadUrl("https://www.youtube.com/embed/$videoId?playsinline=1&rel=0")
            }
        }
    )
}

private fun extractYouTubeId(value: String): String? {
    val input = value.trim()
    val patterns = listOf(
        Regex("(?:youtube\\.com/watch\\?v=|youtu\\.be/|youtube\\.com/shorts/)([A-Za-z0-9_-]{11})"),
        Regex("^[A-Za-z0-9_-]{11}$")
    )
    return patterns.firstNotNullOfOrNull { it.find(input)?.groupValues?.getOrNull(1) }
}

private fun Modifier.clipNeon(): Modifier = this
    .border(1.5.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(18.dp))

@Composable
private fun ComingSoonScreen(title: String) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            NeonPanel {
                Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Spacer(Modifier.height(6.dp))
                Text("Tato služba zatím není připojena. Nezobrazujeme žádná falešná videa ani náhledy.", color = textSecondary)
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Header()
        }
        item {
            NeonPanel {
                Text("Nastavení", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Text("Reálné služby přidáváme postupně. Aktuálně pracujeme na YouTube přehrávání a následně na minimizeru.", color = textSecondary, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
private fun NeonSearchField(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.border(1.7.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp)),
        singleLine = true,
        placeholder = { Text("Hledat videa…", color = textSecondary) },
        leadingIcon = { Text("⌕", fontSize = 30.sp, color = textPrimary) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
            focusedContainerColor = Color(0xE8091020),
            unfocusedContainerColor = Color(0xE8091020),
            focusedTextColor = textPrimary,
            unfocusedTextColor = textPrimary,
            cursorColor = neonBlue
        )
    )
}

@Composable
private fun NeonPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .border(1.5.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp))
            .background(Color(0xEA0A0D18), RoundedCornerShape(22.dp))
            .padding(18.dp),
        content = content
    )
}

@Composable
private fun NeonButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xE8101630), contentColor = textPrimary),
        border = androidx.compose.foundation.BorderStroke(1.dp, neonBlue),
        shape = RoundedCornerShape(16.dp)
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun AioneBottomBar(selected: Module, onSelect: (Module) -> Unit) {
    Surface(
        color = Color(0xF5070812), tonalElevation = 5.dp,
        modifier = Modifier.fillMaxWidth().border(androidx.compose.foundation.BorderStroke(1.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink))))
    ) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(72.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(Module.HOME, Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK, Module.SETTINGS).forEach { module ->
                val isSelected = selected == module
                Box(Modifier.weight(1f).fillMaxHeight().clickable { onSelect(module) }, contentAlignment = Alignment.Center) {
                    Image(painter = painterResource(module.imageRes), contentDescription = module.title, modifier = Modifier.size(if (isSelected) 49.dp else 42.dp), contentScale = ContentScale.Fit)
                }
            }
        }
    }
}
