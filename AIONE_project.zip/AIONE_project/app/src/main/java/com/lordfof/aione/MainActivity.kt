package com.lordfof.aione

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.CookieManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private enum class Module(val title: String, val imageRes: Int) {
    HOME("Domů", R.drawable.ic_aione),
    YOUTUBE("YouTube", R.drawable.ic_youtube),
    TIKTOK("TikTok", R.drawable.ic_tiktok),
    INSTAGRAM("Instagram", R.drawable.ic_instagram),
    FACEBOOK("Facebook", R.drawable.ic_facebook),
    SETTINGS("Nastavení", R.drawable.ic_settings)
}

private data class YouTubeVideo(
    val id: String,
    val title: String,
    val channel: String,
    val thumbnailUrl: String,
    val durationSec: Int = 0
)

private val neonBlue = Color(0xFF19CFFF)
private val neonPurple = Color(0xFF8D35FF)
private val neonPink = Color(0xFFFF20B8)
private val pageBackground = Color(0xFF03040A)
private val textPrimary = Color(0xFFF8F8FF)
private val textSecondary = Color(0xFFD8DBEA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContextHolder.context = applicationContext
        setContent { AioneApp() }
    }
}

@Composable
private fun AioneApp() {
    var selected by remember { mutableStateOf(Module.HOME) }

    // Keep YouTube state at app level so switching to another network does not reset it.
    var youtubeQuery by rememberSaveable { mutableStateOf("") }
    var youtubeSearchRequested by rememberSaveable { mutableStateOf("") }
    var youtubeVideos by remember { mutableStateOf<List<YouTubeVideo>>(emptyList()) }
    var youtubeReels by remember { mutableStateOf<List<YouTubeVideo>>(emptyList()) }
    var youtubeSelectedVideo by remember { mutableStateOf<YouTubeVideo?>(null) }
    var homeOpenReelId by rememberSaveable { mutableStateOf<String?>(null) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(pageBackground)) {
            Image(
                painter = painterResource(R.drawable.aione_neon_frame),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.72f
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.32f)))

            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = { AioneBottomBar(selected = selected, onSelect = { selected = it }) }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    // Keep the YouTube screen composed even when another network is selected.
                    // This preserves the WebView/player position instead of recreating it.
                    YouTubeScreen(
                        modifier = Modifier.fillMaxSize().graphicsLayer { alpha = if (selected == Module.YOUTUBE) 1f else 0f },
                        active = selected == Module.YOUTUBE,
                        query = youtubeQuery,
                        onQueryChange = { youtubeQuery = it },
                        searchRequested = youtubeSearchRequested,
                        onSearchRequested = { youtubeSearchRequested = it },
                        videos = youtubeVideos,
                        onVideosChange = { youtubeVideos = it },
                        reels = youtubeReels,
                        onReelsChange = { youtubeReels = it },
                        selectedVideo = youtubeSelectedVideo,
                        onSelectedVideoChange = { youtubeSelectedVideo = it },
                        openReelId = null,
                        onOpenReelHandled = {}
                    )
                    if (selected != Module.YOUTUBE) {
                        when (selected) {
                            Module.HOME -> HomeScreen(
                                reels = youtubeReels,
                                onOpenYouTube = { selected = Module.YOUTUBE },
                                onOpenReel = { reel -> homeOpenReelId = reel.id }
                            )
                            Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK -> ComingSoonScreen(selected.title)
                            Module.SETTINGS -> SettingsScreen()
                            Module.YOUTUBE -> Unit
                        }
                    }

                }
            }

            // Home Reel viewer is above the whole Scaffold, including the bottom bar.
            if (selected == Module.HOME && homeOpenReelId != null) {
                HomeReelOverlay(
                    videos = youtubeReels,
                    initialVideoId = homeOpenReelId,
                    onClose = { homeOpenReelId = null }
                )
            }
        }
    }
}

@Composable
private fun Header(
    showSearch: Boolean = false,
    searchText: String = "",
    onSearchChange: (String) -> Unit = {},
    onSearch: () -> Unit = {}
) {
    Row(
        modifier = Modifier.fillMaxWidth().height(76.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.aione_wordmark),
            contentDescription = "AIONE",
            modifier = Modifier.width(155.dp).height(58.dp),
            contentScale = ContentScale.Fit
        )
        if (showSearch) {
            NeonSearchField(searchText, onSearchChange, onSearch, Modifier.weight(1f).height(58.dp))
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    reels: List<YouTubeVideo>,
    onOpenYouTube: () -> Unit,
    onOpenReel: (YouTubeVideo) -> Unit
) {
    val shuffledReels = remember(reels) { reels.shuffled() }
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            Text("Pro tebe", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
        }
        if (reels.isEmpty()) {
            item {
                NeonButton("OTEVŘÍT YOUTUBE REELS", onClick = onOpenYouTube)
            }
        } else {
            item {
                Text("Reels", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = textPrimary)
            }
            items(shuffledReels, key = { it.id }) { reel ->
                YouTubeResultCard(video = reel, onClick = { onOpenReel(reel) })
            }
        }
    }
}

@Composable
private fun YouTubeScreen(
    modifier: Modifier = Modifier,
    active: Boolean = true,
    query: String,
    onQueryChange: (String) -> Unit,
    searchRequested: String,
    onSearchRequested: (String) -> Unit,
    videos: List<YouTubeVideo>,
    onVideosChange: (List<YouTubeVideo>) -> Unit,
    reels: List<YouTubeVideo>,
    onReelsChange: (List<YouTubeVideo>) -> Unit,
    selectedVideo: YouTubeVideo?,
    onSelectedVideoChange: (YouTubeVideo?) -> Unit,
    openReelId: String?,
    onOpenReelHandled: () -> Unit
) {
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var videoSearchMode by rememberSaveable { mutableStateOf(false) }
    var reelsLoaded by rememberSaveable { mutableStateOf(false) }
    var reelsMode by rememberSaveable { mutableStateOf(true) }

    LaunchedEffect(openReelId, videos) {
        if (openReelId != null && videos.any { it.id == openReelId }) {
            reelsMode = true
        }
    }

    LaunchedEffect(reelsLoaded) {
        if (!reelsLoaded) {
            loading = true
            error = ""
            try {
                val result = searchYouTube("#shorts", shortsOnly = true)
                onReelsChange(result)
                reelsLoaded = true
                if (result.isEmpty()) error = "YouTube nevrátil žádná krátká videa."
            } catch (e: Exception) {
                error = e.message ?: "Načtení YouTube Reels selhalo."
                onReelsChange(emptyList())
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(searchRequested) {
        if (searchRequested.isBlank() || !videoSearchMode) return@LaunchedEffect
        loading = true
        error = ""
        try {
            val result = searchYouTube(searchRequested, shortsOnly = false)
            onVideosChange(result)
            if (result.isEmpty()) error = "YouTube nevrátil žádné výsledky."
        } catch (e: Exception) {
            error = e.message ?: "Vyhledávání YouTube selhalo."
            onVideosChange(emptyList())
        } finally {
            loading = false
        }
    }

    Box(modifier.fillMaxSize()) {
        if (reelsMode) {
            YouTubeReelsViewer(
                videos = reels,
                active = active,
                onClose = { reelsMode = false },
                onOpenVideos = { reelsMode = false; videoSearchMode = true },
                initialVideoId = openReelId
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item { Header() }

                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.2.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(18.dp))
                            .background(Color(0xEA0A0D18), RoundedCornerShape(18.dp))
                            .padding(5.dp),
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Button(
                            onClick = {
                                if (videoSearchMode) {
                                    videoSearchMode = false
                                    error = ""
                                }
                                reelsMode = true
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!videoSearchMode) Color(0xFF17284A) else Color.Transparent,
                                contentColor = textPrimary
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("REELS", fontWeight = FontWeight.Bold) }
                        Button(
                            onClick = {
                                videoSearchMode = true
                                reelsMode = false
                                error = ""
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (videoSearchMode) Color(0xFF17284A) else Color.Transparent,
                                contentColor = textPrimary
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("VIDEA", fontWeight = FontWeight.Bold) }
                    }
                }

                if (videoSearchMode) {
                    item {
                        Header(
                            showSearch = true,
                            searchText = query,
                            onSearchChange = onQueryChange,
                            onSearch = {
                                val text = query.trim()
                                if (!loading && text.isNotBlank()) onSearchRequested(text)
                            }
                        )
                    }
                }
                if (loading) {
                    item {
                        NeonPanel {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(color = neonBlue, modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(12.dp))
                                Text(if (videoSearchMode) "Hledám na YouTube…" else "Načítám Reels…", color = textSecondary)
                            }
                        }
                    }
                }

                if (error.isNotBlank()) {
                    item { NeonPanel { Text(error, color = Color(0xFFFF7895)) } }
                }

                if (videoSearchMode) {
                    items(videos, key = { it.id }) { video ->
                        YouTubeResultCard(video = video, onClick = { onSelectedVideoChange(video) })
                    }
                }
            }

            // Video mode keeps the requested centered popup with the background dimmed.
            if (selectedVideo != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.80f)),
                    contentAlignment = Alignment.Center
                ) {
                    YouTubePlayerPopup(
                        video = selectedVideo,
                        active = active,
                        onClose = { onSelectedVideoChange(null) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeReelOverlay(
    videos: List<YouTubeVideo>,
    initialVideoId: String?,
    onClose: () -> Unit
) {
    if (videos.isEmpty()) return
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        YouTubeReelsViewer(
            videos = videos,
            active = true,
            onClose = onClose,
            onOpenVideos = onClose,
            initialVideoId = initialVideoId
        )
    }
}

@Composable
private fun YouTubeReelsViewer(
    videos: List<YouTubeVideo>,
    active: Boolean,
    onClose: () -> Unit,
    onOpenVideos: () -> Unit,
    initialVideoId: String? = null
) {
    if (videos.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Žádné Shorts k přehrání.", color = textPrimary, fontSize = 18.sp)
        }
        return
    }

    val initialPage = remember(videos, initialVideoId) {
        videos.indexOfFirst { it.id == initialVideoId }.takeIf { it >= 0 } ?: 0
    }
    key(initialVideoId, videos.map { it.id }) {
        val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { videos.size })
        Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xF5070812))
                .statusBarsPadding()
                .height(54.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onClose) {
                Text("←", color = textPrimary, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            }
            Text("REELS", color = textPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onOpenVideos) {
                Text("VIDEA", color = neonBlue, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }

            Box(Modifier.fillMaxSize()) {
                VerticalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    beyondViewportPageCount = 0
                ) { page ->
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        YouTubePlayer(
                            videoId = videos[page].id,
                            active = active && pagerState.currentPage == page,
                            autoplay = true,
                            muted = true,
                            fullScreen = true
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun YouTubePlayerPopup(
    video: YouTubeVideo,
    active: Boolean,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp)
            .border(1.5.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp))
            .background(Color(0xFF070912), RoundedCornerShape(22.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(video.title, color = textPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                Text(video.channel, color = textSecondary, fontSize = 13.sp, maxLines = 1)
            }
            TextButton(onClick = onClose) {
                Text("✕", color = textPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
        }
        YouTubePlayer(video.id, active = active, autoplay = true, muted = true)
    }
}

@Composable
private fun YouTubeResultCard(video: YouTubeVideo, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.2.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(18.dp))
            .background(Color(0xEA0A0D18), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RemoteThumbnail(video.thumbnailUrl, Modifier.width(150.dp).height(88.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(video.title, color = textPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 3)
            Spacer(Modifier.height(5.dp))
            Text(video.channel, color = textSecondary, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
private fun RemoteThumbnail(url: String, modifier: Modifier = Modifier) {
    var bitmap by remember(url) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(url) {
        bitmap = withContext(Dispatchers.IO) {
            runCatching {
                (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                }.run {
                    inputStream.use { BitmapFactory.decodeStream(it) }
                }
            }.getOrNull()
        }
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF111522)),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text("NAČÍTÁM", color = textSecondary, fontSize = 11.sp)
        }
    }
}

private suspend fun searchYouTube(query: String, shortsOnly: Boolean = false): List<YouTubeVideo> = withContext(Dispatchers.IO) {
    val apiKey = BuildConfig.YOUTUBE_API_KEY
    if (apiKey.isBlank()) throw IllegalStateException("Chybí YouTube API klíč.")

    val encodedQuery = URLEncoder.encode(query, "UTF-8")
    val endpoint = "https://www.googleapis.com/youtube/v3/search" +
        "?part=snippet" +
        "&q=$encodedQuery" +
        "&type=video" +
        "&maxResults=20" +
        (if (shortsOnly) "&videoDuration=short" else "") +
        "&videoSyndicated=true" +
        "&safeSearch=strict" +
        "&regionCode=CZ" +
        "&relevanceLanguage=cs" +
        "&key=${URLEncoder.encode(apiKey, "UTF-8")}"

    val connection = URL(endpoint).openConnection() as HttpURLConnection
    connection.connectTimeout = 10000
    connection.readTimeout = 10000
    connection.requestMethod = "GET"
    try {
        val responseCode = connection.responseCode
        val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (responseCode !in 200..299) {
            val message = runCatching { JSONObject(body).getJSONObject("error").getJSONArray("errors").getJSONObject(0).getString("reason") }.getOrNull()
            throw IllegalStateException("YouTube API chyba${if (message != null) ": $message" else "."}")
        }

        val root = JSONObject(body)
        val items = root.optJSONArray("items") ?: return@withContext emptyList()
        val candidates = buildList {
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val id = item.optJSONObject("id")?.optString("videoId").orEmpty()
                val snippet = item.optJSONObject("snippet") ?: continue
                if (id.isBlank()) continue
                val title = snippet.optString("title", "YouTube video")
                val description = snippet.optString("description", "")
                if (shortsOnly && !((title + " " + description).contains("#shorts", ignoreCase = true) ||
                            title.contains("shorts", ignoreCase = true))) continue
                val thumbs = snippet.optJSONObject("thumbnails")
                val thumbnail = thumbs?.optJSONObject("high")?.optString("url")
                    ?: thumbs?.optJSONObject("medium")?.optString("url")
                    ?: thumbs?.optJSONObject("default")?.optString("url")
                    ?: ""
                add(
                    YouTubeVideo(
                        id = id,
                        title = title,
                        channel = snippet.optString("channelTitle", ""),
                        thumbnailUrl = thumbnail
                    )
                )
            }
        }

        if (!shortsOnly || candidates.isEmpty()) return@withContext candidates

        // The Data API has no dedicated "Shorts only" switch. We therefore combine
        // a #shorts search with the short-duration filter and keep only videos up to
        // three minutes, matching the current Shorts format more closely.
        val ids = candidates.joinToString(",") { it.id }
        val detailUrl = "https://www.googleapis.com/youtube/v3/videos" +
            "?part=contentDetails" +
            "&id=${URLEncoder.encode(ids, "UTF-8")}" +
            "&key=${URLEncoder.encode(apiKey, "UTF-8")}"
        val detailConnection = URL(detailUrl).openConnection() as HttpURLConnection
        detailConnection.connectTimeout = 10000
        detailConnection.readTimeout = 10000
        detailConnection.requestMethod = "GET"
        try {
            val detailCode = detailConnection.responseCode
            val detailBody = (if (detailCode in 200..299) detailConnection.inputStream else detailConnection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (detailCode !in 200..299) return@withContext emptyList()
            val detailItems = JSONObject(detailBody).optJSONArray("items") ?: return@withContext emptyList()
            val durations = mutableMapOf<String, Int>()
            for (i in 0 until detailItems.length()) {
                val item = detailItems.getJSONObject(i)
                val id = item.optString("id")
                val iso = item.optJSONObject("contentDetails")?.optString("duration").orEmpty()
                durations[id] = parseIsoDurationSeconds(iso)
            }
            candidates.filter { (durations[it.id] ?: Int.MAX_VALUE) <= 180 }
                .map { it.copy(durationSec = durations[it.id] ?: 0) }
        } finally {
            detailConnection.disconnect()
        }
    } finally {
        connection.disconnect()
    }
}

private fun parseIsoDurationSeconds(value: String): Int {
    val match = Regex("PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?").matchEntire(value) ?: return Int.MAX_VALUE
    val hours = match.groupValues[1].toIntOrNull() ?: 0
    val minutes = match.groupValues[2].toIntOrNull() ?: 0
    val seconds = match.groupValues[3].toIntOrNull() ?: 0
    return hours * 3600 + minutes * 60 + seconds
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YouTubePlayer(
    videoId: String,
    active: Boolean,
    autoplay: Boolean = false,
    muted: Boolean = false,
    fullScreen: Boolean = false
) {
    AndroidView(
        modifier = if (fullScreen) Modifier.fillMaxSize().background(Color.Black) else Modifier.fillMaxWidth().height(235.dp).clip(RoundedCornerShape(18.dp)).background(Color.Black),
        factory = { context ->
            WebView(context).apply {
                val activity = context as? Activity
                var customView: View? = null
                var customViewCallback: WebChromeClient.CustomViewCallback? = null

                setBackgroundColor(android.graphics.Color.BLACK)
                setLayerType(View.LAYER_TYPE_HARDWARE, null)

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val host = request.url.host.orEmpty()
                        return host != "www.youtube.com" &&
                            host != "youtube.com" &&
                            host != "m.youtube.com" &&
                            host != "www.youtube-nocookie.com" &&
                            host != "youtube-nocookie.com"
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                        if (view == null || activity == null || customView != null) {
                            callback?.onCustomViewHidden()
                            return
                        }
                        customView = view
                        customViewCallback = callback
                        val decor = activity.window.decorView as ViewGroup
                        decor.addView(view, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                        view.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
                    }

                    override fun onHideCustomView() {
                        val view = customView ?: return
                        (activity?.window?.decorView as? ViewGroup)?.removeView(view)
                        customView = null
                        customViewCallback?.onCustomViewHidden()
                        customViewCallback = null
                    }
                }

                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                settings.javaScriptCanOpenWindowsAutomatically = false
                settings.setSupportZoom(false)
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.userAgentString = WebSettings.getDefaultUserAgent(context)

                // Keep the WebView media environment enabled, but do not inject a custom
                // Media Integrity configuration here. The embedded YouTube player can then
                // use the normal WebView playback path without an extra compatibility layer.
                tag = videoId
                loadYouTubeEmbed(this, videoId, autoplay, muted)
            }
        },
        update = { webView ->
            val expectedId = videoId
            if (webView.tag != expectedId) {
                webView.tag = expectedId
                loadYouTubeEmbed(webView, expectedId, autoplay, muted)
            }
            if (!active) webView.onPause() else webView.onResume()
        }
    )
}


private fun loadYouTubeEmbed(
    webView: WebView,
    videoId: String,
    autoplay: Boolean,
    muted: Boolean
) {
    val safeId = videoId.replace(Regex("[^A-Za-z0-9_-]"), "")
    val autoplayValue = if (autoplay) 1 else 0
    val muteValue = if (muted) 1 else 0
    val embedUrl = "https://www.youtube.com/embed/$safeId" +
        "?playsinline=1&controls=1&fs=1&rel=0&enablejsapi=1" +
        "&autoplay=$autoplayValue&mute=$muteValue" +
        "&origin=https%3A%2F%2Fcom.lordfof.aione&hl=cs"

    // Use an HTML wrapper with an HTTPS base URL. YouTube explicitly documents
    // loadDataWithBaseURL() as the Android WebView way to provide a Referer for
    // embedded players. This avoids adding a synthetic Origin header to the
    // navigation request, which can interfere with YouTube's embed handshake.
    val html = """
        <!doctype html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <style>
                html, body { margin:0; padding:0; width:100%; height:100%; background:#000; overflow:hidden; }
                iframe { position:absolute; inset:0; width:100%; height:100%; border:0; background:#000; }
            </style>
        </head>
        <body>
            <iframe
                src="$embedUrl"
                title="YouTube"
                allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
                allowfullscreen
                referrerpolicy="strict-origin-when-cross-origin">
            </iframe>
        </body>
        </html>
    """.trimIndent()

    webView.loadDataWithBaseURL(
        "https://com.lordfof.aione/",
        html,
        "text/html",
        "UTF-8",
        null
    )
}


private object AppContextHolder {
    lateinit var context: Context
}


@Composable
private fun ComingSoonScreen(title: String) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            NeonPanel {
                Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Spacer(Modifier.height(6.dp))
                Text("Tato služba zatím není připojena. Nezobrazujeme žádná falešná videa ani náhledy.", color = textSecondary)
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            NeonPanel {
                Text("Nastavení", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Spacer(Modifier.height(10.dp))
                Text("YouTube", color = neonBlue, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "YouTube API je zabudované přímo do sestavené verze AIONE. Není potřeba zadávat ani ukládat API klíč v aplikaci.",
                    color = textSecondary
                )
            }
        }
    }
}

@Composable
private fun NeonSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.border(1.7.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp)),
        singleLine = true,
        placeholder = { Text("Hledat videa…", color = textSecondary) },
        leadingIcon = { Text("⌕", fontSize = 30.sp, color = textPrimary) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
            focusedContainerColor = Color(0xE8091020),
            unfocusedContainerColor = Color(0xE8091020),
            focusedTextColor = textPrimary,
            unfocusedTextColor = textPrimary,
            cursorColor = neonBlue
        )
    )
}

@Composable
private fun NeonPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .border(1.5.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp))
            .background(Color(0xEA0A0D18), RoundedCornerShape(22.dp))
            .padding(18.dp),
        content = content
    )
}

@Composable
private fun NeonButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xE8101630), contentColor = textPrimary),
        border = BorderStroke(1.dp, neonBlue),
        shape = RoundedCornerShape(16.dp)
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun AioneBottomBar(selected: Module, onSelect: (Module) -> Unit) {
    Surface(
        color = Color(0xF5070812), tonalElevation = 5.dp,
        modifier = Modifier.fillMaxWidth().border(BorderStroke(1.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink))))
    ) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(72.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(Module.HOME, Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK, Module.SETTINGS).forEach { module ->
                val isSelected = selected == module
                Box(Modifier.weight(1f).fillMaxHeight().clickable { onSelect(module) }, contentAlignment = Alignment.Center) {
                    Image(painter = painterResource(module.imageRes), contentDescription = module.title, modifier = Modifier.size(if (isSelected) 49.dp else 42.dp), contentScale = ContentScale.Fit)
                }
            }
        }
    }
}
