package com.lordfof.aione

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private enum class Module(val title: String, val imageRes: Int) {
    HOME("Domů", R.drawable.ic_aione),
    YOUTUBE("YouTube", R.drawable.ic_youtube),
    TIKTOK("TikTok", R.drawable.ic_tiktok),
    INSTAGRAM("Instagram", R.drawable.ic_instagram),
    FACEBOOK("Facebook", R.drawable.ic_facebook),
    SETTINGS("Nastavení", R.drawable.ic_settings)
}

private data class YouTubeVideo(
    val id: String,
    val title: String,
    val channel: String,
    val thumbnailUrl: String
)

private val neonBlue = Color(0xFF19CFFF)
private val neonPurple = Color(0xFF8D35FF)
private val neonPink = Color(0xFFFF20B8)
private val pageBackground = Color(0xFF03040A)
private val textPrimary = Color(0xFFF8F8FF)
private val textSecondary = Color(0xFFD8DBEA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContextHolder.context = applicationContext
        setContent { AioneApp() }
    }
}

@Composable
private fun AioneApp() {
    var selected by remember { mutableStateOf(Module.HOME) }

    // Keep YouTube state at app level so switching to another network does not reset it.
    var youtubeQuery by rememberSaveable { mutableStateOf("") }
    var youtubeSearchRequested by rememberSaveable { mutableStateOf("") }
    var youtubeVideos by remember { mutableStateOf<List<YouTubeVideo>>(emptyList()) }
    var youtubeSelectedVideo by remember { mutableStateOf<YouTubeVideo?>(null) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(pageBackground)) {
            Image(
                painter = painterResource(R.drawable.aione_neon_frame),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.72f
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.32f)))

            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = { AioneBottomBar(selected = selected, onSelect = { selected = it }) }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    // Keep the YouTube screen composed even when another network is selected.
                    // This preserves the WebView/player position instead of recreating it.
                    YouTubeScreen(
                        modifier = Modifier.fillMaxSize().graphicsLayer { alpha = if (selected == Module.YOUTUBE) 1f else 0f },
                        active = selected == Module.YOUTUBE,
                        query = youtubeQuery,
                        onQueryChange = { youtubeQuery = it },
                        searchRequested = youtubeSearchRequested,
                        onSearchRequested = { youtubeSearchRequested = it },
                        videos = youtubeVideos,
                        onVideosChange = { youtubeVideos = it },
                        selectedVideo = youtubeSelectedVideo,
                        onSelectedVideoChange = { youtubeSelectedVideo = it }
                    )
                    if (selected != Module.YOUTUBE) {
                        when (selected) {
                            Module.HOME -> HomeScreen(onOpenYouTube = { selected = Module.YOUTUBE })
                            Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK -> ComingSoonScreen(selected.title)
                            Module.SETTINGS -> SettingsScreen()
                            Module.YOUTUBE -> Unit
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(
    showSearch: Boolean = false,
    searchText: String = "",
    onSearchChange: (String) -> Unit = {},
    onSearch: () -> Unit = {}
) {
    Row(
        modifier = Modifier.fillMaxWidth().height(76.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.aione_wordmark),
            contentDescription = "AIONE",
            modifier = Modifier.width(155.dp).height(58.dp),
            contentScale = ContentScale.Fit
        )
        if (showSearch) {
            NeonSearchField(searchText, onSearchChange, onSearch, Modifier.weight(1f).height(58.dp))
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onOpenYouTube: () -> Unit
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            NeonPanel {
                Text("Pro tebe", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Spacer(Modifier.height(6.dp))
                Text(
                    "AIONE zatím nezobrazuje žádná falešná videa. Začínáme skutečným YouTube vyhledáváním.",
                    color = textSecondary, fontSize = 15.sp
                )
                Spacer(Modifier.height(14.dp))
                NeonButton("OTEVŘÍT YOUTUBE", onClick = onOpenYouTube)
            }
        }
    }
}

@Composable
private fun YouTubeScreen(
    modifier: Modifier = Modifier,
    active: Boolean = true,
    query: String,
    onQueryChange: (String) -> Unit,
    searchRequested: String,
    onSearchRequested: (String) -> Unit,
    videos: List<YouTubeVideo>,
    onVideosChange: (List<YouTubeVideo>) -> Unit,
    selectedVideo: YouTubeVideo?,
    onSelectedVideoChange: (YouTubeVideo?) -> Unit
) {
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    if (selectedVideo != null) {
        LazyColumn(
            modifier = modifier,
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Header() }
            item {
                NeonButton("← ZPĚT NA VÝSLEDKY", onClick = { onSelectedVideoChange(null) })
            }
            item {
                NeonPanel {
                    Text(selectedVideo.title, color = textPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(selectedVideo.channel, color = textSecondary, fontSize = 14.sp)
                }
            }
            item { YouTubePlayer(selectedVideo.id, active = active) }
        }
        return
    }

    LaunchedEffect(searchRequested) {
        if (searchRequested.isBlank()) return@LaunchedEffect
        loading = true
        error = ""
        try {
            val result = searchYouTube(searchRequested)
            onVideosChange(result)
            if (result.isEmpty()) error = "YouTube nevrátil žádné výsledky."
        } catch (e: Exception) {
            error = e.message ?: "Vyhledávání YouTube selhalo."
            onVideosChange(emptyList())
        } finally {
            loading = false
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Header(
                showSearch = true,
                searchText = query,
                onSearchChange = onQueryChange,
                onSearch = {
                    val text = query.trim()
                    if (!loading && text.isNotBlank()) onSearchRequested(text)
                }
            )
        }
        if (query.isBlank() && videos.isEmpty()) {
            item {
                NeonPanel {
                    Text("Skutečné YouTube vyhledávání", color = textPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Napiš hledaný výraz a AIONE načte skutečné výsledky z YouTube. Žádná demo videa.",
                        color = textSecondary
                    )
                }
            }
        }
        if (error.isNotBlank()) {
            item {
                NeonPanel {
                    Text(error, color = Color(0xFFFF7895))
                }
            }
        }
        items(videos, key = { it.id }) { video ->
            YouTubeResultCard(video = video, onClick = { onSelectedVideoChange(video) })
        }
    }
}

@Composable
private fun YouTubeResultCard(video: YouTubeVideo, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.2.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(18.dp))
            .background(Color(0xEA0A0D18), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RemoteThumbnail(video.thumbnailUrl, Modifier.width(150.dp).height(88.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(video.title, color = textPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 3)
            Spacer(Modifier.height(5.dp))
            Text(video.channel, color = textSecondary, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
private fun RemoteThumbnail(url: String, modifier: Modifier = Modifier) {
    var bitmap by remember(url) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(url) {
        bitmap = withContext(Dispatchers.IO) {
            runCatching {
                (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                }.run {
                    inputStream.use { BitmapFactory.decodeStream(it) }
                }
            }.getOrNull()
        }
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF111522)),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text("NAČÍTÁM", color = textSecondary, fontSize = 11.sp)
        }
    }
}

private suspend fun searchYouTube(query: String): List<YouTubeVideo> = withContext(Dispatchers.IO) {
    val apiKey = BuildConfig.YOUTUBE_API_KEY
    if (apiKey.isBlank()) throw IllegalStateException("Chybí YouTube API klíč.")

    val encodedQuery = URLEncoder.encode(query, "UTF-8")
    val endpoint = "https://www.googleapis.com/youtube/v3/search" +
        "?part=snippet" +
        "&q=$encodedQuery" +
        "&type=video" +
        "&maxResults=20" +
        "&videoSyndicated=true" +
        "&safeSearch=strict" +
        "&regionCode=CZ" +
        "&relevanceLanguage=cs" +
        "&key=${URLEncoder.encode(apiKey, "UTF-8")}"

    val connection = URL(endpoint).openConnection() as HttpURLConnection
    connection.connectTimeout = 10000
    connection.readTimeout = 10000
    connection.requestMethod = "GET"
    try {
        val responseCode = connection.responseCode
        val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (responseCode !in 200..299) {
            val message = runCatching { JSONObject(body).getJSONObject("error").getJSONArray("errors").getJSONObject(0).getString("reason") }.getOrNull()
            throw IllegalStateException("YouTube API chyba${if (message != null) ": $message" else "."}")
        }

        val root = JSONObject(body)
        val items = root.optJSONArray("items") ?: return@withContext emptyList()
        buildList {
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val id = item.optJSONObject("id")?.optString("videoId").orEmpty()
                val snippet = item.optJSONObject("snippet") ?: continue
                if (id.isBlank()) continue
                val thumbs = snippet.optJSONObject("thumbnails")
                val thumbnail = thumbs?.optJSONObject("medium")?.optString("url")
                    ?: thumbs?.optJSONObject("default")?.optString("url")
                    ?: ""
                add(
                    YouTubeVideo(
                        id = id,
                        title = snippet.optString("title", "YouTube video"),
                        channel = snippet.optString("channelTitle", ""),
                        thumbnailUrl = thumbnail
                    )
                )
            }
        }
    } finally {
        connection.disconnect()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YouTubePlayer(videoId: String, active: Boolean) {
    AndroidView(
        modifier = Modifier.fillMaxWidth().height(235.dp).clip(RoundedCornerShape(18.dp)).background(Color.Black),
        factory = { context ->
            WebView(context).apply {
                val activity = context as? Activity
                var customView: View? = null
                var customViewCallback: WebChromeClient.CustomViewCallback? = null

                setBackgroundColor(android.graphics.Color.BLACK)
                setLayerType(View.LAYER_TYPE_HARDWARE, null)

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val host = request.url.host.orEmpty()
                        return host != "www.youtube.com" &&
                            host != "youtube.com" &&
                            host != "m.youtube.com" &&
                            host != "www.youtube-nocookie.com" &&
                            host != "youtube-nocookie.com"
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                        if (view == null || activity == null || customView != null) {
                            callback?.onCustomViewHidden()
                            return
                        }
                        customView = view
                        customViewCallback = callback
                        val decor = activity.window.decorView as ViewGroup
                        decor.addView(view, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                        view.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
                    }

                    override fun onHideCustomView() {
                        val view = customView ?: return
                        (activity?.window?.decorView as? ViewGroup)?.removeView(view)
                        customView = null
                        customViewCallback?.onCustomViewHidden()
                        customViewCallback = null
                    }
                }

                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = true
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                settings.javaScriptCanOpenWindowsAutomatically = false
                settings.setSupportZoom(false)
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.userAgentString = WebSettings.getDefaultUserAgent(context)

                // Keep the WebView media environment enabled, but do not inject a custom
                // Media Integrity configuration here. The embedded YouTube player can then
                // use the normal WebView playback path without an extra compatibility layer.
                tag = videoId
                val embedUrl = youtubeEmbedUrl(videoId)
                loadUrl(
                    embedUrl,
                    mapOf(
                        "Referer" to "https://www.youtube.com/",
                        "Origin" to "https://www.youtube.com"
                    )
                )
            }
        },
        update = { webView ->
            val expectedId = videoId
            if (webView.tag != expectedId) {
                webView.tag = expectedId
                webView.loadUrl(
                    youtubeEmbedUrl(expectedId),
                    mapOf(
                        "Referer" to "https://www.youtube.com/",
                        "Origin" to "https://www.youtube.com"
                    )
                )
            }
            if (!active) webView.onPause() else webView.onResume()
        }
    )
}


private fun youtubeEmbedUrl(videoId: String): String {
    val safeId = videoId.replace(Regex("[^A-Za-z0-9_-]"), "")
    return "https://www.youtube.com/embed/$safeId?playsinline=1&controls=1&fs=1&rel=0&modestbranding=1&enablejsapi=1&autoplay=0&origin=https%3A%2F%2Fwww.youtube.com&hl=cs"
}


private object AppContextHolder {
    lateinit var context: Context
}


@Composable
private fun ComingSoonScreen(title: String) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            NeonPanel {
                Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Spacer(Modifier.height(6.dp))
                Text("Tato služba zatím není připojena. Nezobrazujeme žádná falešná videa ani náhledy.", color = textSecondary)
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            NeonPanel {
                Text("Nastavení", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Spacer(Modifier.height(10.dp))
                Text("YouTube", color = neonBlue, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "YouTube API je zabudované přímo do sestavené verze AIONE. Není potřeba zadávat ani ukládat API klíč v aplikaci.",
                    color = textSecondary
                )
            }
        }
    }
}

@Composable
private fun NeonSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.border(1.7.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp)),
        singleLine = true,
        placeholder = { Text("Hledat videa…", color = textSecondary) },
        leadingIcon = { Text("⌕", fontSize = 30.sp, color = textPrimary) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
            focusedContainerColor = Color(0xE8091020),
            unfocusedContainerColor = Color(0xE8091020),
            focusedTextColor = textPrimary,
            unfocusedTextColor = textPrimary,
            cursorColor = neonBlue
        )
    )
}

@Composable
private fun NeonPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .border(1.5.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp))
            .background(Color(0xEA0A0D18), RoundedCornerShape(22.dp))
            .padding(18.dp),
        content = content
    )
}

@Composable
private fun NeonButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xE8101630), contentColor = textPrimary),
        border = BorderStroke(1.dp, neonBlue),
        shape = RoundedCornerShape(16.dp)
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun AioneBottomBar(selected: Module, onSelect: (Module) -> Unit) {
    Surface(
        color = Color(0xF5070812), tonalElevation = 5.dp,
        modifier = Modifier.fillMaxWidth().border(BorderStroke(1.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink))))
    ) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(72.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(Module.HOME, Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK, Module.SETTINGS).forEach { module ->
                val isSelected = selected == module
                Box(Modifier.weight(1f).fillMaxHeight().clickable { onSelect(module) }, contentAlignment = Alignment.Center) {
                    Image(painter = painterResource(module.imageRes), contentDescription = module.title, modifier = Modifier.size(if (isSelected) 49.dp else 42.dp), contentScale = ContentScale.Fit)
                }
            }
        }
    }
}
