package com.lordfof.aione

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class Module(val title: String, val icon: String) {
    HOME("Domů", "⌂"),
    YOUTUBE("YouTube", "▶"),
    TIKTOK("TikTok", "♪"),
    INSTAGRAM("Instagram", "◎"),
    FACEBOOK("Facebook", "f"),
    SETTINGS("Nastavení", "⚙")
}

private data class Reel(
    val source: Module,
    val creator: String,
    val title: String,
    val accent: List<Color>
)

private val demoReels = listOf(
    Reel(Module.YOUTUBE, "AIONE Demo", "První video v našem společném feedu", listOf(Color(0xFF5B2C6F), Color(0xFF1B4965))),
    Reel(Module.TIKTOK, "Creator One", "Krátké video z TikToku", listOf(Color(0xFF111111), Color(0xFF6A1B9A))),
    Reel(Module.INSTAGRAM, "@aione", "Instagram Reel", listOf(Color(0xFF833AB4), Color(0xFFE1306C))),
    Reel(Module.FACEBOOK, "Facebook Creator", "Facebook Reel", listOf(Color(0xFF1877F2), Color(0xFF0D47A1))),
    Reel(Module.YOUTUBE, "AIONE", "Další Shorts video", listOf(Color(0xFFB71C1C), Color(0xFF4A148C)))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AioneApp() }
    }
}

@Composable
private fun AioneApp() {
    var selected by remember { mutableStateOf(Module.HOME) }
    var miniPlayerVisible by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            bottomBar = {
                AioneBottomBar(selected = selected, onSelect = { selected = it })
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                when (selected) {
                    Module.HOME -> HomeFeed(onOpenPlayer = { miniPlayerVisible = true })
                    Module.YOUTUBE -> ServiceFeed(Module.YOUTUBE, onOpenPlayer = { miniPlayerVisible = true })
                    Module.TIKTOK -> ServiceFeed(Module.TIKTOK, onOpenPlayer = { miniPlayerVisible = true })
                    Module.INSTAGRAM -> ServiceFeed(Module.INSTAGRAM, onOpenPlayer = { miniPlayerVisible = true })
                    Module.FACEBOOK -> ServiceFeed(Module.FACEBOOK, onOpenPlayer = { miniPlayerVisible = true })
                    Module.SETTINGS -> SettingsScreen()
                }

                if (miniPlayerVisible) {
                    MiniPlayer(onClose = { miniPlayerVisible = false })
                }
            }
        }
    }
}

@Composable
private fun HomeFeed(onOpenPlayer: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Text("AIONE", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Pro tebe", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Reels ze všech tvých sítí na jednom místě",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        items(demoReels) { reel ->
            ReelCard(reel = reel, onOpenPlayer = onOpenPlayer)
        }
    }
}

@Composable
private fun ServiceFeed(module: Module, onOpenPlayer: () -> Unit) {
    val reels = demoReels.filter { it.source == module }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Text(module.title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(
                "Obsah pouze z této služby",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        items(if (reels.isEmpty()) demoReels.take(1) else reels) { reel ->
            ReelCard(reel = reel.copy(source = module), onOpenPlayer = onOpenPlayer)
        }
    }
}

@Composable
private fun ReelCard(reel: Reel, onOpenPlayer: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.62f)
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                    .background(Brush.linearGradient(reel.accent)),
                contentAlignment = Alignment.BottomStart
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.35f))
                        .padding(14.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.Black.copy(alpha = 0.55f)
                    ) {
                        Text(
                            "${reel.source.icon}  ${reel.source.title}",
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(reel.title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(reel.creator, color = Color.White.copy(alpha = 0.85f))
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = {}) { Text("♥") }
                TextButton(onClick = {}) { Text("💬") }
                TextButton(onClick = {}) { Text("↗") }
                TextButton(onClick = {}) { Text("🔖") }
                TextButton(onClick = onOpenPlayer) { Text("▶") }
            }
        }
    }
}

@Composable
private fun MiniPlayer(onClose: () -> Unit) {
    Card(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(start = 10.dp, end = 10.dp, bottom = 10.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("▶", fontSize = 24.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Mini přehrávač", fontWeight = FontWeight.Bold)
                Text("Připraveno pro společný Media Engine", maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            TextButton(onClick = onClose) { Text("Zavřít") }
        }
    }
}

@Composable
private fun SettingsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Nastavení", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Nastavení AIONE budeme přidávat postupně.")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Společný feed", fontWeight = FontWeight.Bold)
                Text("Později zde půjde nastavit, které služby se mají ve For You feedu zobrazovat.")
            }
        }
    }
}

@Composable
private fun AioneBottomBar(selected: Module, onSelect: (Module) -> Unit) {
    Surface(tonalElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(72.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf(
                Module.HOME,
                Module.YOUTUBE,
                Module.TIKTOK,
                Module.INSTAGRAM,
                Module.FACEBOOK,
                Module.SETTINGS
            ).forEach { module ->
                val isSelected = selected == module
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onSelect(module) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        module.icon,
                        fontSize = 20.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        module.title,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}
