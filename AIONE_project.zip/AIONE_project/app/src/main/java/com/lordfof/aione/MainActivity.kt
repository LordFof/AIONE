package com.lordfof.aione

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class Module(val title: String, val emoji: String) {
    HOME("Domů", "⌂"), YOUTUBE("YouTube", "▶"), TIKTOK("TikTok", "♪"), INSTAGRAM("Instagram", "◎"), FACEBOOK("Facebook", "f"), DOWNLOADS("Stažené", "↓"), SAVED("Oblíbené", "♥"), SETTINGS("Nastavení", "⚙")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AioneApp() }
    }
}

@Composable
private fun AioneApp() {
    var selected by remember { mutableStateOf(Module.HOME) }
    var miniPlayerVisible by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf(Module.HOME, Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK, Module.SETTINGS).forEach { module ->
                        NavigationBarItem(
                            selected = selected == module,
                            onClick = { selected = module },
                            icon = { Text(module.emoji, fontSize = 20.sp) },
                            label = { Text(module.title) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("AIONE", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Jedno místo pro tvoje média", color = MaterialTheme.colorScheme.onSurfaceVariant)

                if (miniPlayerVisible) {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("▶", fontSize = 28.sp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Mini přehrávač", fontWeight = FontWeight.Bold)
                                Text("Připraveno pro Media Engine")
                            }
                            TextButton(onClick = { miniPlayerVisible = false }) { Text("Zavřít") }
                        }
                    }
                }

                Text(selected.title, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                ModuleContent(selected) { miniPlayerVisible = true }
            }
        }
    }
}

@Composable
private fun ModuleContent(module: Module, showPlayer: () -> Unit) {
    when (module) {
        Module.HOME -> {
            Text("AIONE propojí služby do jednoho přehledného prostředí.")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf(Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK)) { item ->
                    AssistChip(onClick = {}, label = { Text(item.emoji + " " + item.title) })
                }
            }
            Button(onClick = showPlayer) { Text("Otevřít testovací mini-player") }
        }
        Module.YOUTUBE -> ServicePlaceholder("YouTube", "Zde bude YouTube modul a náš Media Engine.", showPlayer)
        Module.TIKTOK -> ServicePlaceholder("TikTok", "Zde bude samostatný TikTok konektor.", showPlayer)
        Module.INSTAGRAM -> ServicePlaceholder("Instagram", "Zde bude Instagram / Reels konektor.", showPlayer)
        Module.FACEBOOK -> ServicePlaceholder("Facebook", "Zde bude Facebook / Reels konektor.", showPlayer)
        Module.DOWNLOADS -> Text("Místo pro lokálně dostupný obsah a stažené položky.")
        Module.SAVED -> Text("Místo pro oblíbené a uložené položky.")
        Module.SETTINGS -> Text("Nastavení AIONE bude přidáno postupně.")
    }
}

@Composable
private fun ServicePlaceholder(title: String, description: String, showPlayer: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(description)
            Button(onClick = showPlayer) { Text("Test mini-playeru") }
        }
    }
}
