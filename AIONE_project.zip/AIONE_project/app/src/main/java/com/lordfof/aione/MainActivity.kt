package com.lordfof.aione

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private enum class Module(val title: String, val imageRes: Int) {
    HOME("Domů", R.drawable.ic_aione),
    YOUTUBE("YouTube", R.drawable.ic_youtube),
    TIKTOK("TikTok", R.drawable.ic_tiktok),
    INSTAGRAM("Instagram", R.drawable.ic_instagram),
    FACEBOOK("Facebook", R.drawable.ic_facebook),
    SETTINGS("Nastavení", R.drawable.ic_settings)
}

private data class Reel(
    val id: Int,
    val source: Module,
    val creator: String,
    val title: String,
    val views: String,
    val age: String,
    val duration: String,
    val tags: List<String>,
    val thumbnailRes: Int
)

private val demoReels = listOf(
    Reel(1, Module.YOUTUBE, "Nature World", "Neuvěřitelné přírodní scenérie 8K", "2,4 mil. zhlédnutí", "před 3 dny", "12:34", listOf("priroda", "cestovani", "8k", "hory"), R.drawable.thumb_youtube),
    Reel(2, Module.TIKTOK, "CutePets", "Nejroztomilejší kočky na světě 🐱", "5,1 mil. zhlédnutí", "před 1 dnem", "00:28", listOf("zvirata", "kocky", "zabava"), R.drawable.thumb_tiktok),
    Reel(3, Module.INSTAGRAM, "travel.journey", "Cestování po Evropě 🌍", "1,8 mil. zhlédnutí", "před 5 dny", "01:12", listOf("cestovani", "evropa", "hory", "inspirace"), R.drawable.thumb_instagram),
    Reel(4, Module.FACEBOOK, "Fitness Life", "Motivace pro každý den 💪", "3,7 mil. zhlédnutí", "před 2 dny", "04:21", listOf("sport", "fitness", "motivace"), R.drawable.thumb_facebook),
    Reel(5, Module.YOUTUBE, "Tech Zone", "Novinky ze světa technologií", "842 tis. zhlédnutí", "před 6 hodinami", "08:41", listOf("technologie", "mobil", "novinky"), R.drawable.thumb_youtube),
    Reel(6, Module.TIKTOK, "GameHub", "Herní moment, který nikdo nečekal", "921 tis. zhlédnutí", "před 8 hodinami", "00:41", listOf("gaming", "hry", "zabava"), R.drawable.thumb_tiktok),
    Reel(7, Module.INSTAGRAM, "FoodDaily", "Rychlý recept na dnešní večer", "634 tis. zhlédnutí", "před 1 dnem", "00:57", listOf("jidlo", "recept", "vareni"), R.drawable.thumb_instagram),
    Reel(8, Module.FACEBOOK, "World News", "Co se dnes děje ve světě", "1,2 mil. zhlédnutí", "před 4 hodinami", "02:36", listOf("zpravy", "svet", "novinky"), R.drawable.thumb_facebook)
)

private val neonBlue = Color(0xFF19CFFF)
private val neonPurple = Color(0xFF8D35FF)
private val neonPink = Color(0xFFFF20B8)
private val pageBackground = Color(0xFF05060C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AioneApp() }
    }
}

@Composable
private fun AioneApp() {
    var selected by remember { mutableStateOf(Module.HOME) }
    var viewerOpen by remember { mutableStateOf(false) }
    var viewerStartId by remember { mutableStateOf(1) }
    var searchText by remember { mutableStateOf("") }
    var homeReels by remember { mutableStateOf(demoReels.shuffled()) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        if (viewerOpen) {
            ReelViewer(
                reels = homeReels,
                startId = viewerStartId,
                onBack = { viewerOpen = false },
                onOpenSource = {
                    selected = it
                    viewerOpen = false
                }
            )
            return@MaterialTheme
        }

        Scaffold(
            containerColor = pageBackground,
            bottomBar = {
                AioneBottomBar(selected = selected, onSelect = {
                    selected = it
                    if (it == Module.HOME) homeReels = demoReels.shuffled()
                })
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(pageBackground)
            ) {
                when (selected) {
                    Module.HOME -> HomeFeed(
                        reels = filterReels(homeReels, searchText),
                        searchText = searchText,
                        onSearchChange = { searchText = it },
                        onOpenReel = { reel -> viewerStartId = reel.id; viewerOpen = true },
                        onOpenSource = { selected = it }
                    )
                    Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK -> ServiceFeed(
                        module = selected,
                        reels = filterReels(demoReels.filter { it.source == selected }, searchText),
                        searchText = searchText,
                        onSearchChange = { searchText = it },
                        onOpenReel = { reel -> viewerStartId = reel.id; viewerOpen = true },
                        onOpenSource = { selected = it }
                    )
                    Module.SETTINGS -> SettingsScreen()
                }
            }
        }
    }
}

private fun filterReels(reels: List<Reel>, query: String): List<Reel> {
    val terms = query.trim().lowercase()
        .split(Regex("[\\s,]+"))
        .map { it.removePrefix("#") }
        .filter { it.isNotBlank() }
    if (terms.isEmpty()) return reels
    return reels.filter { reel ->
        terms.all { term ->
            reel.tags.any { it.contains(term) } ||
                reel.title.lowercase().contains(term) ||
                reel.creator.lowercase().contains(term)
        }
    }
}

@Composable
private fun NeonSearchField(value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.5.dp,
                brush = Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)),
                shape = RoundedCornerShape(22.dp)
            ),
        singleLine = true,
        placeholder = { Text("Hledat videa nebo #tag...") },
        leadingIcon = { Text("⌕", fontSize = 30.sp, color = Color.White) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
            focusedContainerColor = Color(0xFF0A1020),
            unfocusedContainerColor = Color(0xFF0A1020),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedPlaceholderColor = Color.White.copy(alpha = .62f),
            unfocusedPlaceholderColor = Color.White.copy(alpha = .62f)
        )
    )
}

@Composable
private fun HomeFeed(
    reels: List<Reel>,
    searchText: String,
    onSearchChange: (String) -> Unit,
    onOpenReel: (Reel) -> Unit,
    onOpenSource: (Module) -> Unit
) {
    FeedScaffold(
        title = "Pro tebe",
        subtitle = "Náhodný výběr videí ze všech sítí",
        searchText = searchText,
        onSearchChange = onSearchChange,
        reels = reels,
        onOpenReel = onOpenReel,
        onOpenSource = onOpenSource
    )
}

@Composable
private fun ServiceFeed(
    module: Module,
    reels: List<Reel>,
    searchText: String,
    onSearchChange: (String) -> Unit,
    onOpenReel: (Reel) -> Unit,
    onOpenSource: (Module) -> Unit
) {
    FeedScaffold(
        title = module.title,
        subtitle = "Obsah pouze z této služby",
        searchText = searchText,
        onSearchChange = onSearchChange,
        reels = reels,
        onOpenReel = onOpenReel,
        onOpenSource = onOpenSource
    )
}

@Composable
private fun FeedScaffold(
    title: String,
    subtitle: String,
    searchText: String,
    onSearchChange: (String) -> Unit,
    reels: List<Reel>,
    onOpenReel: (Reel) -> Unit,
    onOpenSource: (Module) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(88.dp)
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_aione),
                    contentDescription = "AIONE",
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .size(88.dp),
                    contentScale = ContentScale.Fit
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxWidth(.66f)
                ) {
                    Text("AIONE", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text(subtitle, color = Color.White.copy(alpha = .68f), fontSize = 13.sp)
                }
            }
        }
        item {
            NeonSearchField(searchText, onSearchChange)
        }
        item {
            SourceTabs(title = title, onOpenSource = onOpenSource)
        }
        if (reels.isEmpty()) {
            item {
                NeonPanel {
                    Text("Nic nenalezeno", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Zkus jiný tag nebo více tagů oddělených mezerou.",
                        color = Color.White.copy(alpha = .7f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        } else {
            items(reels, key = { it.id }) { reel ->
                ReelCard(reel, onOpenReel, onOpenSource)
            }
        }
    }
}

@Composable
private fun SourceTabs(title: String, onOpenSource: (Module) -> Unit) {
    val tabs = listOf(Module.HOME, Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        tabs.forEach { module ->
            val active = title == module.title || (title == "Pro tebe" && module == Module.HOME)
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clickable { onOpenSource(module) },
                shape = RoundedCornerShape(18.dp),
                color = if (active) Color(0xFF15182B) else Color(0xFF080B15),
                border = BorderStroke(
                    1.dp,
                    if (active) Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink))
                    else Brush.linearGradient(listOf(Color(0xFF26304D), Color(0xFF18203A)))
                )
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(if (module == Module.HOME) "Pro tebe" else module.title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun ReelCard(
    reel: Reel,
    onOpenReel: (Reel) -> Unit,
    onOpenSource: (Module) -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(
                1.5.dp,
                Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)),
                shape
            )
            .background(Color(0xFF0B0D17))
            .clickable { onOpenReel(reel) }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.80f)
        ) {
            Image(
                painter = painterResource(reel.thumbnailRes),
                contentDescription = reel.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Surface(
                modifier = Modifier
                    .padding(12.dp)
                    .size(48.dp)
                    .clickable { onOpenSource(reel.source) },
                shape = RoundedCornerShape(15.dp),
                color = Color(0xE8000715)
            ) {
                Image(
                    painter = painterResource(reel.source.imageRes),
                    contentDescription = reel.source.title,
                    modifier = Modifier.padding(5.dp),
                    contentScale = ContentScale.Fit
                )
            }
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp),
                shape = RoundedCornerShape(18.dp),
                color = Color(0xA6000000)
            ) {
                Text("⋮", fontSize = 23.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp))
            }
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(12.dp),
                shape = RoundedCornerShape(9.dp),
                color = Color(0xDD000000)
            ) {
                Text(reel.duration, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp))
            }
        }
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(reel.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text(
                "${reel.creator} · ${reel.views} · ${reel.age}",
                color = Color.White.copy(alpha = .66f),
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                reel.tags.take(3).forEach { tag ->
                    Surface(shape = RoundedCornerShape(50), color = Color(0xFF15172A)) {
                        Text("#$tag", fontSize = 11.sp, color = Color.White.copy(alpha = .8f), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ReelViewer(
    reels: List<Reel>,
    startId: Int,
    onBack: () -> Unit,
    onOpenSource: (Module) -> Unit
) {
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(startId) {
        val index = reels.indexOfFirst { it.id == startId }
        if (index >= 0) state.scrollToItem(index)
    }

    Box(Modifier.fillMaxSize().background(pageBackground)) {
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 78.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(reels, key = { it.id }) { reel ->
                ReelCard(reel, onOpenReel = { scope.launch { state.animateScrollToItem(reels.indexOf(it)) } }, onOpenSource = onOpenSource)
            }
        }
        Surface(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .size(48.dp)
                .clickable { onBack() },
            shape = RoundedCornerShape(16.dp),
            color = Color(0xD9000715),
            border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple)))
        ) {
            Box(contentAlignment = Alignment.Center) { Text("‹", fontSize = 30.sp) }
        }
        Text(
            "Reels ze všech sítí",
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 25.dp),
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp
        )
    }
}

@Composable
private fun NeonPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .border(1.5.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp))
            .background(Color(0xFF0A0D18))
            .padding(18.dp),
        content = content
    )
}

@Composable
private fun SettingsScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Nastavení", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("AIONE", color = Color.White.copy(alpha = .6f), modifier = Modifier.padding(top = 2.dp))
        }
        item {
            NeonPanel {
                Text("Společný feed", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Text("Domů náhodně míchá obsah ze všech připojených služeb.", color = Color.White.copy(alpha = .7f), modifier = Modifier.padding(top = 5.dp))
            }
        }
        item {
            NeonPanel {
                Text("Tagy", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Text("Do vyhledávání můžeš napsat jeden nebo více tagů. AIONE pak zobrazí videa, která odpovídají všem zadaným výrazům.", color = Color.White.copy(alpha = .7f), modifier = Modifier.padding(top = 5.dp))
            }
        }
        item {
            NeonPanel {
                Text("Přehrávání", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Text("Další krok bude skutečné přehrávání a později full-screen režim Reels.", color = Color.White.copy(alpha = .7f), modifier = Modifier.padding(top = 5.dp))
            }
        }
    }
}

@Composable
private fun AioneBottomBar(selected: Module, onSelect: (Module) -> Unit) {
    Surface(
        color = Color(0xFF070812),
        tonalElevation = 5.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Brush.horizontalGradient(listOf(Color(0xFF142B4D), Color(0xFF55226C), Color(0xFF142B4D))), RoundedCornerShape(0.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(72.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf(Module.HOME, Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK, Module.SETTINGS).forEach { module ->
                val isSelected = selected == module
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onSelect(module) },
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(module.imageRes),
                        contentDescription = module.title,
                        modifier = Modifier.size(if (isSelected) 49.dp else 42.dp),
                        contentScale = ContentScale.Fit,
                        alpha = if (isSelected) 1f else .78f
                    )
                }
            }
        }
    }
}
