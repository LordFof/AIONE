package com.lordfof.aione

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class Module(val title: String, val imageRes: Int) {
    HOME("Domů", R.drawable.ic_aione),
    YOUTUBE("YouTube", R.drawable.ic_youtube),
    TIKTOK("TikTok", R.drawable.ic_tiktok),
    INSTAGRAM("Instagram", R.drawable.ic_instagram),
    FACEBOOK("Facebook", R.drawable.ic_facebook),
    SETTINGS("Nastavení", R.drawable.ic_settings)
}

private data class Reel(
    val id: Int,
    val source: Module,
    val creator: String,
    val title: String,
    val views: String,
    val age: String,
    val duration: String,
    val tags: List<String>,
    val thumbnailRes: Int
)

private val demoReels = listOf(
    Reel(1, Module.YOUTUBE, "Nature World", "Neuvěřitelné přírodní scenérie 8K", "2,4 mil. zhlédnutí", "před 3 dny", "12:34", listOf("priroda", "cestovani", "8k", "hory"), R.drawable.thumb_youtube),
    Reel(2, Module.TIKTOK, "CutePets", "Nejroztomilejší kočky na světě 🐱", "5,1 mil. zhlédnutí", "před 1 dnem", "00:28", listOf("zvirata", "kocky", "zabava"), R.drawable.thumb_tiktok),
    Reel(3, Module.INSTAGRAM, "travel.journey", "Cestování po Evropě 🌍", "1,8 mil. zhlédnutí", "před 5 dny", "01:12", listOf("cestovani", "evropa", "hory", "inspirace"), R.drawable.thumb_instagram),
    Reel(4, Module.FACEBOOK, "Fitness Life", "Motivace pro každý den 💪", "3,7 mil. zhlédnutí", "před 2 dny", "04:21", listOf("sport", "fitness", "motivace"), R.drawable.thumb_facebook),
    Reel(5, Module.YOUTUBE, "Tech Zone", "Novinky ze světa technologií", "842 tis. zhlédnutí", "před 6 hodinami", "08:41", listOf("technologie", "mobil", "novinky"), R.drawable.thumb_youtube),
    Reel(6, Module.TIKTOK, "GameHub", "Herní moment, který nikdo nečekal", "921 tis. zhlédnutí", "před 8 hodinami", "00:41", listOf("gaming", "hry", "zabava"), R.drawable.thumb_tiktok),
    Reel(7, Module.INSTAGRAM, "FoodDaily", "Rychlý recept na dnešní večer", "634 tis. zhlédnutí", "před 1 dnem", "00:57", listOf("jidlo", "recept", "vareni"), R.drawable.thumb_instagram),
    Reel(8, Module.FACEBOOK, "World News", "Co se dnes děje ve světě", "1,2 mil. zhlédnutí", "před 4 hodinami", "02:36", listOf("zpravy", "svet", "novinky"), R.drawable.thumb_facebook)
)

private val neonBlue = Color(0xFF19CFFF)
private val neonPurple = Color(0xFF8D35FF)
private val neonPink = Color(0xFFFF20B8)
private val pageBackground = Color(0xFF03040A)
private val panelBackground = Color(0xE80A0D18)
private val textPrimary = Color(0xFFF8F8FF)
private val textSecondary = Color(0xFFD8DBEA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AioneApp() }
    }
}

@Composable
private fun AioneApp() {
    var selected by remember { mutableStateOf(Module.HOME) }
    var viewerOpen by remember { mutableStateOf(false) }
    var viewerReels by remember { mutableStateOf(demoReels.shuffled()) }
    var searchText by remember { mutableStateOf("") }
    var homeReels by remember { mutableStateOf(demoReels.shuffled()) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(pageBackground)) {
            Image(
                painter = painterResource(R.drawable.aione_neon_frame),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.72f
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.32f)))

            if (viewerOpen) {
                ReelViewer(
                    reels = viewerReels,
                    onBack = { viewerOpen = false },
                    onOpenSource = {
                        selected = it
                        viewerOpen = false
                    }
                )
            } else {
                Scaffold(
                    containerColor = Color.Transparent,
                    bottomBar = {
                        AioneBottomBar(selected = selected, onSelect = {
                            selected = it
                            if (it == Module.HOME) homeReels = demoReels.shuffled()
                        })
                    }
                ) { padding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                    ) {
                        when (selected) {
                            Module.HOME -> HomeFeed(
                                reels = filterReels(homeReels, searchText),
                                searchText = searchText,
                                onSearchChange = { searchText = it },
                                onOpenReel = { reel ->
                                    viewerReels = listOf(reel) + demoReels.filter { it.id != reel.id }.shuffled()
                                    viewerOpen = true
                                },
                                onOpenSource = { selected = it }
                            )
                            Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK -> ServiceFeed(
                                module = selected,
                                reels = filterReels(demoReels.filter { it.source == selected }, searchText),
                                searchText = searchText,
                                onSearchChange = { searchText = it },
                                onOpenReel = { reel ->
                                    val serviceReels = demoReels.filter { it.source == selected }
                                    viewerReels = listOf(reel) + serviceReels.filter { it.id != reel.id }.shuffled()
                                    viewerOpen = true
                                },
                                onOpenSource = { selected = it }
                            )
                            Module.SETTINGS -> SettingsScreen()
                        }
                    }
                }
            }
        }
    }
}

private fun filterReels(reels: List<Reel>, query: String): List<Reel> {
    val terms = query.trim().lowercase()
        .split(Regex("[\\s,]+"))
        .map { it.removePrefix("#") }
        .filter { it.isNotBlank() }
    if (terms.isEmpty()) return reels
    return reels.filter { reel ->
        terms.all { term ->
            reel.tags.any { it.contains(term) } ||
                reel.title.lowercase().contains(term) ||
                reel.creator.lowercase().contains(term)
        }
    }
}

@Composable
private fun NeonSearchField(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier
            .border(1.7.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp)),
        singleLine = true,
        placeholder = { Text("Hledat videa nebo #tag...", color = textSecondary) },
        leadingIcon = { Text("⌕", fontSize = 30.sp, color = textPrimary) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
            focusedContainerColor = Color(0xE8091020),
            unfocusedContainerColor = Color(0xE8091020),
            focusedTextColor = textPrimary,
            unfocusedTextColor = textPrimary,
            cursorColor = neonBlue,
            focusedPlaceholderColor = textSecondary,
            unfocusedPlaceholderColor = textSecondary
        )
    )
}

@Composable
private fun HomeFeed(
    reels: List<Reel>,
    searchText: String,
    onSearchChange: (String) -> Unit,
    onOpenReel: (Reel) -> Unit,
    onOpenSource: (Module) -> Unit
) = FeedScaffold("Pro tebe", "Náhodný výběr videí ze všech sítí", searchText, onSearchChange, reels, onOpenReel, onOpenSource)

@Composable
private fun ServiceFeed(
    module: Module,
    reels: List<Reel>,
    searchText: String,
    onSearchChange: (String) -> Unit,
    onOpenReel: (Reel) -> Unit,
    onOpenSource: (Module) -> Unit
) = FeedScaffold(module.title, "Obsah pouze z této služby", searchText, onSearchChange, reels, onOpenReel, onOpenSource)

@Composable
private fun FeedScaffold(
    title: String,
    subtitle: String,
    searchText: String,
    onSearchChange: (String) -> Unit,
    reels: List<Reel>,
    onOpenReel: (Reel) -> Unit,
    onOpenSource: (Module) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().height(76.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Image(
                    painter = painterResource(R.drawable.aione_wordmark),
                    contentDescription = "AIONE",
                    modifier = Modifier.width(155.dp).height(58.dp),
                    contentScale = ContentScale.Fit
                )
                NeonSearchField(searchText, onSearchChange, Modifier.weight(1f).height(58.dp))
            }
        }
        if (reels.isEmpty()) {
            item {
                NeonPanel {
                    Text("Nic nenalezeno", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                    Text("Zkus jiný tag nebo více tagů oddělených mezerou.", color = textSecondary, modifier = Modifier.padding(top = 4.dp))
                }
            }
        } else {
            items(reels, key = { it.id }) { reel -> ReelCard(reel, onOpenReel, onOpenSource) }
        }
    }
}

@Composable
private fun ReelCard(reel: Reel, onOpenReel: (Reel) -> Unit, onOpenSource: (Module) -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(1.5.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), shape)
            .background(panelBackground)
            .clickable { onOpenReel(reel) }
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.80f)) {
            Image(painter = painterResource(reel.thumbnailRes), contentDescription = reel.title, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Surface(
                modifier = Modifier.padding(12.dp).size(48.dp).clickable { onOpenSource(reel.source) },
                shape = RoundedCornerShape(15.dp), color = Color(0xE8000715)
            ) { Image(painter = painterResource(reel.source.imageRes), contentDescription = reel.source.title, modifier = Modifier.padding(5.dp), contentScale = ContentScale.Fit) }
            Surface(Modifier.align(Alignment.TopEnd).padding(12.dp), RoundedCornerShape(18.dp), color = Color(0xC8000000)) {
                Text("⋮", fontSize = 23.sp, color = Color.White, modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp))
            }
            Surface(Modifier.align(Alignment.BottomEnd).padding(12.dp), RoundedCornerShape(9.dp), color = Color(0xDD000000)) {
                Text(reel.duration, fontSize = 12.sp, color = Color.White, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp))
            }
        }
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(reel.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = textPrimary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text("${reel.creator} · ${reel.views} · ${reel.age}", color = textSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                reel.tags.take(4).forEach { tag ->
                    Surface(shape = RoundedCornerShape(50), color = Color(0xE0161B30), border = BorderStroke(1.dp, Color(0xFF33456E))) {
                        Text("#$tag", fontSize = 11.sp, color = textPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ReelViewer(reels: List<Reel>, onBack: () -> Unit, onOpenSource: (Module) -> Unit) {
    val state = rememberLazyListState()
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(reels, key = { it.id }) { reel ->
                ReelPage(reel, onOpenSource)
            }
        }
        Surface(
            modifier = Modifier.align(Alignment.TopStart).padding(14.dp).size(48.dp).clickable { onBack() },
            shape = RoundedCornerShape(16.dp), color = Color(0xD9000715), border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple)))
        ) { Box(contentAlignment = Alignment.Center) { Text("‹", fontSize = 30.sp, color = Color.White) } }
    }
}

@Composable
private fun ReelPage(reel: Reel, onOpenSource: (Module) -> Unit) {
    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    Box(
        modifier = Modifier.fillMaxWidth().height(screenHeight).background(Color.Black)
    ) {
        Image(painter = painterResource(reel.thumbnailRes), contentDescription = reel.title, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Color.Black.copy(alpha = .9f)))))
        Surface(
            modifier = Modifier.padding(start = 18.dp, top = 18.dp).size(58.dp).clickable { onOpenSource(reel.source) },
            shape = RoundedCornerShape(17.dp), color = Color(0xEE000714), border = BorderStroke(1.2.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple)))
        ) { Image(painter = painterResource(reel.source.imageRes), contentDescription = reel.source.title, modifier = Modifier.padding(6.dp), contentScale = ContentScale.Fit) }
        Column(
            modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(reel.source.title, color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                Surface(shape = RoundedCornerShape(9.dp), color = Color(0xCC000000)) { Text(reel.duration, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) }
            }
            Spacer(Modifier.height(8.dp))
            Text(reel.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 25.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text("${reel.creator} · ${reel.views} · ${reel.age}", color = textSecondary, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                reel.tags.take(4).forEach { tag ->
                    Surface(shape = RoundedCornerShape(50), color = Color(0xC9000615), border = BorderStroke(1.dp, Color(0xFF415C91))) {
                        Text("#$tag", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun NeonPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .border(1.5.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp))
            .background(Color(0xEA0A0D18)).padding(18.dp),
        content = content
    )
}

@Composable
private fun SettingsScreen() {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Nastavení", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = textPrimary)
            Text("AIONE", color = textSecondary, modifier = Modifier.padding(top = 2.dp))
        }
        item { NeonPanel { Text("Společný feed", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = textPrimary); Text("Domů náhodně míchá obsah ze všech připojených služeb.", color = textSecondary, modifier = Modifier.padding(top = 5.dp)) } }
        item { NeonPanel { Text("Tagy", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = textPrimary); Text("Do vyhledávání můžeš napsat jeden nebo více tagů. AIONE pak zobrazí videa, která odpovídají všem zadaným výrazům.", color = textSecondary, modifier = Modifier.padding(top = 5.dp)) } }
        item { NeonPanel { Text("Přehrávání", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = textPrimary); Text("Kliknutí na video otevře samostatný Reel režim, ve kterém můžeš scrollovat další náhodná videa. Full-screen přehrávání doplníme později.", color = textSecondary, modifier = Modifier.padding(top = 5.dp)) } }
    }
}

@Composable
private fun AioneBottomBar(selected: Module, onSelect: (Module) -> Unit) {
    Surface(
        color = Color(0xF5070812), tonalElevation = 5.dp,
        modifier = Modifier.fillMaxWidth().border(BorderStroke(1.dp, Brush.horizontalGradient(listOf(Color(0xFF19CFFF), Color(0xFF8D35FF), Color(0xFFFF20B8)))))
    ) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(72.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(Module.HOME, Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK, Module.SETTINGS).forEach { module ->
                val isSelected = selected == module
                Box(Modifier.weight(1f).fillMaxHeight().clickable { onSelect(module) }, contentAlignment = Alignment.Center) {
                    Image(painter = painterResource(module.imageRes), contentDescription = module.title, modifier = Modifier.size(if (isSelected) 49.dp else 42.dp), contentScale = ContentScale.Fit)
                }
            }
        }
    }
}
