package com.lordfof.aione

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.view.View
import android.view.ViewGroup
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.CookieManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.tiktok.open.sdk.auth.AuthApi
import com.tiktok.open.sdk.auth.AuthRequest
import com.tiktok.open.sdk.auth.utils.PKCEUtils

private enum class Module(val title: String, val imageRes: Int) {
    HOME("Domů", R.drawable.ic_aione),
    YOUTUBE("YouTube", R.drawable.ic_youtube),
    TIKTOK("TikTok", R.drawable.ic_tiktok),
    INSTAGRAM("Instagram", R.drawable.ic_instagram),
    FACEBOOK("Facebook", R.drawable.ic_facebook),
    SETTINGS("Nastavení", R.drawable.ic_settings)
}

private val neonBlue = Color(0xFF19CFFF)
private val neonPurple = Color(0xFF8D35FF)
private val neonPink = Color(0xFFFF20B8)
private val pageBackground = Color(0xFF03040A)
private val textPrimary = Color(0xFFF8F8FF)
private val textSecondary = Color(0xFFD8DBEA)

class MainActivity : ComponentActivity() {
    private lateinit var tiktokAuthApi: AuthApi

    private var tiktokAuthMessage by mutableStateOf("")

    private companion object {
        const val TIKTOK_CLIENT_KEY = "aw4nhv7rduufv3mk"
        const val TIKTOK_REDIRECT_URI = "https://lordfof.github.io/AIONE/tiktok/callback"
        const val TIKTOK_CODE_VERIFIER = "tiktok_code_verifier"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tiktokAuthApi = AuthApi(activity = this)
        setContent {
            AioneApp(
                tiktokAuthMessage = tiktokAuthMessage,
                onTikTokLogin = ::startTikTokLogin
            )
        }
        handleTikTokCallback(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleTikTokCallback(intent)
    }

    private fun startTikTokLogin() {
        val codeVerifier = PKCEUtils.generateCodeVerifier()
        getSharedPreferences(TIKTOK_CODE_VERIFIER, Context.MODE_PRIVATE)
            .edit()
            .putString(TIKTOK_CODE_VERIFIER, codeVerifier)
            .apply()

        val request = AuthRequest(
            clientKey = TIKTOK_CLIENT_KEY,
            scope = "user.info.basic",
            redirectUri = TIKTOK_REDIRECT_URI,
            codeVerifier = codeVerifier
        )

        try {
            tiktokAuthApi.authorize(request, AuthApi.AuthMethod.TikTokApp)
            tiktokAuthMessage = "Přihlašování přes TikTok…"
        } catch (_: Exception) {
            try {
                tiktokAuthApi.authorize(request, AuthApi.AuthMethod.ChromeTab)
                tiktokAuthMessage = "Otevírám TikTok přihlášení v prohlížeči…"
            } catch (e: Exception) {
                tiktokAuthMessage = "TikTok přihlášení se nepodařilo spustit."
                Toast.makeText(
                    this,
                    "TikTok Login Kit: ${e.message ?: "chyba"}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun handleTikTokCallback(intent: Intent?) {
        if (intent?.action != Intent.ACTION_VIEW) return
        if (intent.data?.host != "lordfof.github.io") return
        if (intent.data?.path != "/AIONE/tiktok/callback") return

        val codeVerifier = getSharedPreferences(TIKTOK_CODE_VERIFIER, Context.MODE_PRIVATE)
            .getString(TIKTOK_CODE_VERIFIER, "")
            .orEmpty()

        val response = tiktokAuthApi.getAuthResponseFromIntent(intent, TIKTOK_REDIRECT_URI)
            ?: return

        if (response.authCode.isNotEmpty()) {
            tiktokAuthMessage = "TikTok účet byl autorizován. Kód byl přijat."
            Toast.makeText(
                this,
                "TikTok autorizace proběhla. Kód je připraven pro serverové dokončení přihlášení.",
                Toast.LENGTH_LONG
            ).show()
            // The auth code + codeVerifier must be exchanged server-side.
            // The client secret is intentionally not stored in this APK.
        } else {
            val error = response.authErrorDescription
                ?: response.authError
                ?: response.errorMsg
                ?: "Neznámá chyba"
            tiktokAuthMessage = "TikTok autorizace: $error"
            Toast.makeText(this, "TikTok: $error", Toast.LENGTH_LONG).show()
        }

        if (codeVerifier.isEmpty()) {
            tiktokAuthMessage = "Chybí PKCE verifier pro TikTok callback."
        }
    }
}

@Composable
private fun AioneApp(
    tiktokAuthMessage: String = "",
    onTikTokLogin: () -> Unit = {}
) {
    var selected by remember { mutableStateOf(Module.HOME) }
    var homeReelsOpen by remember { mutableStateOf(false) }
    var homeReelsPlatform by remember { mutableStateOf(Module.YOUTUBE) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(Modifier.fillMaxSize().background(pageBackground)) {
            Image(
                painter = painterResource(R.drawable.aione_neon_frame),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.72f
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.32f)))

            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = { AioneBottomBar(selected = selected, onSelect = { selected = it }) }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    // Keep the real YouTube WebView alive while switching between tabs.
                    // This preserves YouTube's own web session, history and current page.
                    YouTubeWebScreen(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { alpha = if (selected == Module.YOUTUBE) 1f else 0f },
                        active = selected == Module.YOUTUBE
                    )

                    if (selected != Module.YOUTUBE) {
                        when (selected) {
                            Module.HOME -> HomeScreen(
                                onOpenYouTube = { selected = Module.YOUTUBE },
                                onOpenRandomReel = {
                                    homeReelsPlatform = listOf(
                                        Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK
                                    ).random()
                                    homeReelsOpen = true
                                }
                            )
                            Module.TIKTOK -> TikTokScreen(
                                active = true,
                                authMessage = tiktokAuthMessage,
                                onLogin = onTikTokLogin
                            )
                            Module.INSTAGRAM -> NetworkWebScreen(Module.INSTAGRAM, active = true)
                            Module.FACEBOOK -> NetworkWebScreen(Module.FACEBOOK, active = true)
                            Module.SETTINGS -> SettingsScreen()
                            Module.YOUTUBE -> Unit
                        }
                    }

                }
            }
        }

        if (homeReelsOpen) {
            HomeReelWebOverlay(
                platform = homeReelsPlatform,
                onClose = { homeReelsOpen = false }
            )
        }
    }
}

@Composable
private fun Header() {
    Row(
        modifier = Modifier.fillMaxWidth().height(76.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.aione_wordmark),
            contentDescription = "AIONE",
            modifier = Modifier.width(155.dp).height(58.dp),
            contentScale = ContentScale.Fit
        )
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onOpenYouTube: () -> Unit,
    onOpenRandomReel: () -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            Text("Pro tebe", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
        }
        item {
            NeonPanel {
                Text(
                    "Náhodné Reels",
                    color = textPrimary,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "AIONE otevře skutečný Reels/Shorts web vybrané sítě. Žádná falešná videa ani náhledy.",
                    color = textSecondary
                )
                Spacer(Modifier.height(14.dp))
                NeonButton("SPUSTIT NÁHODNÝ REEL", onClick = onOpenRandomReel)
                Spacer(Modifier.height(10.dp))
                NeonButton("OTEVŘÍT YOUTUBE", onClick = onOpenYouTube)
            }
        }
        item {
            NeonPanel {
                Text("Živý obsah sítí", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Prozatím používáme přímo weby jednotlivých služeb. Tím se vyhneme rozbitým přehrávačům a zachováme jejich vlastní přehrávání.",
                    color = textSecondary
                )
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YouTubeWebScreen(
    modifier: Modifier = Modifier,
    active: Boolean = true
) {
    AndroidView(
        modifier = modifier.background(Color.Black),
        factory = { context ->
            WebView(context).apply {
                val activity = context as? Activity
                var customView: View? = null
                var customViewCallback: WebChromeClient.CustomViewCallback? = null

                setBackgroundColor(android.graphics.Color.BLACK)
                setLayerType(View.LAYER_TYPE_HARDWARE, null)

                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.allowFileAccess = false
                settings.allowContentAccess = true
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                settings.javaScriptCanOpenWindowsAutomatically = false
                settings.setSupportMultipleWindows(false)
                settings.setSupportZoom(false)
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.userAgentString = WebSettings.getDefaultUserAgent(context)

                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView,
                        request: WebResourceRequest
                    ): Boolean {
                        // Let the complete YouTube site navigate inside this WebView.
                        return false
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                        if (view == null || activity == null || customView != null) {
                            callback?.onCustomViewHidden()
                            return
                        }
                        customView = view
                        customViewCallback = callback
                        val decor = activity.window.decorView as ViewGroup
                        decor.addView(
                            view,
                            ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                        view.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
                    }

                    override fun onHideCustomView() {
                        val view = customView ?: return
                        (activity?.window?.decorView as? ViewGroup)?.removeView(view)
                        customView = null
                        customViewCallback?.onCustomViewHidden()
                        customViewCallback = null
                    }
                }

                loadUrl("https://www.youtube.com/")
            }
        },
        update = { webView ->
            if (active) {
                webView.onResume()
            } else {
                webView.onPause()
            }
        }
    )
}

@Composable
private fun TikTokScreen(
    active: Boolean,
    authMessage: String,
    onLogin: () -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        LiveNetworkWebView(
            url = networkHomeUrl(Module.TIKTOK),
            active = active,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(12.dp),
            horizontalAlignment = Alignment.End
        ) {
            Button(
                onClick = onLogin,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xE8101630)),
                border = BorderStroke(1.dp, neonBlue),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    "PŘIHLÁSIT TIKTOK",
                    color = textPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            if (authMessage.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = Color(0xE8101322),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, neonPurple)
                ) {
                    Text(
                        authMessage,
                        color = textPrimary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun NetworkWebScreen(module: Module, active: Boolean) {
    LiveNetworkWebView(
        url = networkHomeUrl(module),
        active = active,
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun HomeReelWebOverlay(platform: Module, onClose: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        LiveNetworkWebView(
            url = networkReelsUrl(platform),
            active = true,
            modifier = Modifier.fillMaxSize()
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xD90A0D18)),
                border = BorderStroke(1.dp, neonBlue),
                shape = RoundedCornerShape(14.dp)
            ) { Text("ZPĚT", color = textPrimary) }
            Spacer(Modifier.width(12.dp))
            Text(
                when (platform) {
                    Module.YOUTUBE -> "YouTube Shorts"
                    Module.TIKTOK -> "TikTok"
                    Module.INSTAGRAM -> "Instagram Reels"
                    Module.FACEBOOK -> "Facebook Reels"
                    else -> "Reels"
                },
                color = textPrimary,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun networkHomeUrl(module: Module): String = when (module) {
    Module.YOUTUBE -> "https://www.youtube.com/"
    Module.TIKTOK -> "https://www.tiktok.com/"
    Module.INSTAGRAM -> "https://www.instagram.com/"
    Module.FACEBOOK -> "https://www.facebook.com/"
    else -> "https://www.youtube.com/"
}

private fun networkReelsUrl(module: Module): String = when (module) {
    Module.YOUTUBE -> "https://www.youtube.com/shorts/"
    Module.TIKTOK -> "https://www.tiktok.com/"
    Module.INSTAGRAM -> "https://www.instagram.com/reels/"
    Module.FACEBOOK -> "https://www.facebook.com/reels/"
    else -> "https://www.youtube.com/shorts/"
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun LiveNetworkWebView(
    url: String,
    active: Boolean,
    modifier: Modifier = Modifier
) {
    AndroidView(
        modifier = modifier.background(Color.Black),
        factory = { context ->
            WebView(context).apply {
                val activity = context as? Activity
                var customView: View? = null
                var customViewCallback: WebChromeClient.CustomViewCallback? = null

                setBackgroundColor(android.graphics.Color.BLACK)
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.allowFileAccess = false
                settings.allowContentAccess = true
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                settings.javaScriptCanOpenWindowsAutomatically = true
                settings.setSupportMultipleWindows(false)
                settings.setSupportZoom(false)
                settings.builtInZoomControls = false
                settings.displayZoomControls = false
                settings.userAgentString = WebSettings.getDefaultUserAgent(context)

                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                        if (view == null || activity == null || customView != null) {
                            callback?.onCustomViewHidden()
                            return
                        }
                        customView = view
                        customViewCallback = callback
                        (activity.window.decorView as ViewGroup).addView(
                            view,
                            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                        )
                        view.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
                    }

                    override fun onHideCustomView() {
                        val view = customView ?: return
                        (activity?.window?.decorView as? ViewGroup)?.removeView(view)
                        customView = null
                        customViewCallback?.onCustomViewHidden()
                        customViewCallback = null
                    }
                }

                loadUrl(url)
            }
        },
        update = { webView ->
            if (active) webView.onResume() else webView.onPause()
        }
    )
}

@Composable
private fun ComingSoonScreen(title: String) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            NeonPanel {
                Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Spacer(Modifier.height(6.dp))
                Text("Tato služba zatím není připojena. Nezobrazujeme žádná falešná videa ani náhledy.", color = textSecondary)
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header() }
        item {
            NeonPanel {
                Text("Nastavení", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                Spacer(Modifier.height(10.dp))
                Text("YouTube", color = neonBlue, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "AIONE používá přímo plný YouTube web v integrovaném WebView. Vyhledávání, přehrávání, Shorts, přihlášení a další funkce poskytuje samotný YouTube.",
                    color = textSecondary
                )
            }
        }
    }
}

@Composable
private fun NeonPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .border(1.5.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink)), RoundedCornerShape(22.dp))
            .background(Color(0xEA0A0D18), RoundedCornerShape(22.dp))
            .padding(18.dp),
        content = content
    )
}

@Composable
private fun NeonButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xE8101630), contentColor = textPrimary),
        border = BorderStroke(1.dp, neonBlue),
        shape = RoundedCornerShape(16.dp)
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun AioneBottomBar(selected: Module, onSelect: (Module) -> Unit) {
    Surface(
        color = Color(0xF5070812), tonalElevation = 5.dp,
        modifier = Modifier.fillMaxWidth().border(BorderStroke(1.dp, Brush.horizontalGradient(listOf(neonBlue, neonPurple, neonPink))))
    ) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(72.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(Module.HOME, Module.YOUTUBE, Module.TIKTOK, Module.INSTAGRAM, Module.FACEBOOK, Module.SETTINGS).forEach { module ->
                val isSelected = selected == module
                Box(Modifier.weight(1f).fillMaxHeight().clickable { onSelect(module) }, contentAlignment = Alignment.Center) {
                    Image(painter = painterResource(module.imageRes), contentDescription = module.title, modifier = Modifier.size(if (isSelected) 49.dp else 42.dp), contentScale = ContentScale.Fit)
                }
            }
        }
    }
}
