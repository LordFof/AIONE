import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val localProperties = Properties()
val localPropertiesFile = rootProject.file("local.properties")
if (localPropertiesFile.exists()) {
    localPropertiesFile.inputStream().use { localProperties.load(it) }
}
val youtubeApiKey = System.getenv("YOUTUBE_API_KEY")
    ?: localProperties.getProperty("YOUTUBE_API_KEY")
    ?: ""
val escapedYoutubeApiKey = youtubeApiKey.replace("\\", "\\\\").replace("\"", "\\\"")

android {
    namespace = "com.lordfof.aione"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.lordfof.aione"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.2.1"
        buildConfigField("String", "YOUTUBE_API_KEY", "\"$escapedYoutubeApiKey\"")
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation(platform("androidx.compose:compose-bom:2025.01.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
